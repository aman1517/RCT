
const express = require('express')

const Like = require('../model/like.model')




const router = express.Router()


module.exports = router;


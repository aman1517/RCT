function sidebar() {
  return ` <h1>TechCrunch</h1>
<input id="inp" type="text" />`;
  // return your html component here
  //Make sure to give input search box id as ""
}
export default sidebar;
